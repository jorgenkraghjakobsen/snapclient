
let tempGraph;
let tempSeries;

let pvddGraph;
let pvddSeries;


function initTempMonitor() {
  tempSeries = new TimelineDataSeries();
  tempGraph = new TimelineGraphView('tempGraph','tempCanvas');
  tempGraph.updateEndDate();
}

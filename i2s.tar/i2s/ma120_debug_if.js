// Javascript object to control debug interface on ma120

var debug_sel = null;
var rev = 1;
function ma_debug_sel_test1() {
  if (!debug_sel) {
    debug_sel = new DebugSel();
    debug_sel.enable();
  }
}

function ma_debug_sel_test2() {
  debug_sel.disable();
  debug_sel = null;
}

function DebugSel() {
// Must do readmodify to operate acfg muxs in AVDD core
//  Procedure lookup in OTP mem values for
//  reg 3:  amux_ch0, vcf_trim
//  reg 1:  amux_ch1_10, osc_3m_ftrrim
//  reg 0:  amux_ch1_2, test_mode, osc_3m_ctrim

const acfg_muxs = [
  { segment : 'avdd', seg_addr: 1, sel_ch0_addr : 3, sel_ch0_pos : 4, sel_ch1_addr : 1, sel_ch1_pos : 6,
     source : [ 'off', 'tie_off', 'por_1v5_ok', 'vbg_0v6_filt', 'vbgp', 'pbias_bgp', 'pgr_ok', 'nc',
               'nc', 'clk_cal_3m072', 'nc', 'nc', 'vcf_a0_div15', 'vcf_b0_div15', 'vcf_a1_div15', 'vcf_b1_div15'] },
  { segment : 'nb_amux', seg_addr: 3, sel_ch0_addr : 1, sel_ch0_pos : 0, sel_ch1_addr : 1, sel_ch1_pos : 4,
    source  : ['off', 'tie_off', 'int1_vref_cmo' , 'vcm_pwm', 'vcm_lf', 'vint1_n', 'vint1_p', 'vint2_p',
              'vint3_p', 'vref_ff', 'vlf_out', 'nc', 'debug_pos', 'debug_neg','vin1_div4_n','vin1_div4_p']},
  { segment : 'sb_amux', seg_addr: 6, sel_ch0_addr : 0, sel_ch0_pos : 0, sel_ch1_addr : 0, sel_ch1_pos : 4,
    source  : ['off', 'tie_off', 'pvdd_div30', 'nc', 'nc', 'nc', 'nc', 'nc' ,
              'nc', 'nc'     , 'nc'        , 'nc', 'nc', 'nc', 'nc', 'nc' ] },
  { segment : 'lf0h', seg_addr: 10, sel_ch0_addr : 1, sel_ch0_pos : 0, sel_ch1_addr : 1, sel_ch1_pos : 4,
    source  : ['off' , 'tie_off', 'int1_vref_cmo', 'vcm_pwm' , 'vcm_lf' , 'vin1_n', 'vin1_p' ,
              'vin2_p' , 'vin3_p', 'vref_ff', 'vlf_out', 'nc', 'pwm_debug_pos', 'pvm_debug_neg'  ]  },
  { segment : 'pwm0', seg_addr: 11, sel_ch0_addr : 1, sel_ch0_pos : 0, sel_ch1_addr : 1, sel_ch1_pos : 4 ,
    source  : ['off' , 'tie_off', 'int1_vref_cmo', 'vcm_pwm' , 'vcm_lf' , 'vin1_n', 'vin1_p' ,
              'vin2_p' , 'vin3_p', 'vref_ff', 'vlf_out', 'nc', 'pwm_debug_pos', 'pvm_debug_neg'  ]  },
  { segment : 'lf1h', seg_addr: 14, sel_ch0_addr : 1, sel_ch0_pos : 0, sel_ch1_addr : 1, sel_ch1_pos : 4 ,
    source  : ['off' , 'tie_off', 'int1_vref_cmo', 'vcm_pwm' , 'vcm_lf' , 'vin1_n', 'vin1_p' ,
              'vin2_p' , 'vin3_p', 'vref_ff', 'vlf_out', 'nc', 'pwm_debug_pos', 'pvm_debug_neg'  ]  },
  { segment : 'pwm1', seg_addr: 15, sel_ch0_addr : 1, sel_ch0_pos : 0, sel_ch1_addr : 1, sel_ch1_pos : 4 ,
    source  : ['off' , 'tie_off', 'int1_vref_cmo', 'vcm_pwm' , 'vcm_lf' , 'vin1_n', 'vin1_p' ,
              'vin2_p' , 'vin3_p', 'vref_ff', 'vlf_out', 'nc', 'pwm_debug_pos', 'pvm_debug_neg'  ]  }
];

const xpin_modes = [
  'open drain (default)',
  'Digital',
  'Power',
  'Analog Unbuffered',
  'Analog Current',
  'Analog Buffered' ];

const xpin_digs = [ 'clk_24m_int',
    'clk_48m',
    'clk_sys',
    'clk_cal_3m',
    'clk_dco_100m',
    'i2s_sck_int',
    'i2s_audio_tick',
    'audio_tick_48m',
    'afir_clk',
    'afir_din_p0_tmp',
    'afir_din_n0_tmp',
    'afir_dout_p0',
    'afir_dout_n0',
    'afir_din_p1_tmp',
    'afir_din_n1_tmp',
    'afir_dout_p1',
    'afir_dout_n1',
    'clk_pwm_base_4m096_out_int'      ,
    'clk_cp_base_2m048_out_int'       ,
    'gd_on_ls_a0(0)'                  ,
    'gd_on_ls_a0(1)'                  ,
    'gd_on_ls_a0(2)'                  ,
    'gd_on_ls_a0(3)'                  ,
    'pb_gd_fb_a0(0)'                  ,
    'pb_gd_fb_a0(1)'                  ,
    'pb_gd_fb_a0(2)'                  ,
    'pb_gd_fb_a0(3)'                  ,
    'pb_sr_sck_a0'                    ,
    'pb_sr_di_a0'                    ,
    'gd_on_ls_b0(0)'                  ,
    'gd_on_ls_b0(1)'                  ,
    'gd_on_ls_b0(2)'                  ,
    'gd_on_ls_b0(3)'                  ,
    'pb_gd_fb_b0(0)'                  ,
    'pb_gd_fb_b0(1)'                  ,
    'pb_gd_fb_b0(2)'                  ,
    'pb_gd_fb_b0(3)'                  ,
    'pb_sr_sck_b0'                   ,
    'pb_sr_di_b0'                    ,
    'gd_on_ls_a1(0)'                  ,
    'gd_on_ls_a1(1)'                  ,
    'gd_on_ls_a1(2)'                  ,
    'gd_on_ls_a1(3)'                  ,
    'pb_gd_fb_a1(0)'                  ,
    'pb_gd_fb_a1(1)'                  ,
    'pb_gd_fb_a1(2)'                  ,
    'pb_gd_fb_a1(3)'                  ,
    'pb_sr_sck_a1'                   ,
    'pb_sr_di_a1'                    ,
    'gd_on_ls_b1(0)'                  ,
    'gd_on_ls_b1(1)'                  ,
    'gd_on_ls_b1(2)'                  ,
    'gd_on_ls_b1(3)'                  ,
    'pb_gd_fb_b1(0)'                  ,
    'pb_gd_fb_b1(1)'                  ,
    'pb_gd_fb_b1(2)'                  ,
    'pb_gd_fb_b1(3)'                  ,
    'pb_sr_sck_b1'                   ,
    'pb_sr_di_b1'                    ,
    'clk_chop0_int'                  ,
    'clk_chop1_int'                  ,
    'adc_en'                         ,
    'adc_clk'                         ,
    'adc_sw(0)'                       ,
    'adc_sw(1)'                       ,
    'adc_sw(2)'                       ,
    'adc_sadc'                       ,
    'adc_sdac'                       ,
    'temp_update_flip'               ,
    'cmr_sample0_int'                ,
    'dn0_0_int'                      ,
    'dn90_0_int'                     ,
    'dmem_en'                        ,
    'dmem_wr'                        ,
    'dmem_hold'                      ,
    'pmem_en'                        ,
    'pmem_wr'                        ,
    'pmem_hold'                      ,
    'dsp_out_flags(0)'               ,
    'dsp_out_flags(1)'                ,
    '0 or test_mon.afir_sync'             ,
    '0 or test_mon.afir_result_latched'   ,
    'psel'                           ,
    'pready'                         ,
    'prdata(0)'                       ,
    'pwdata(0) or clk_sys_mon.status.i2s_sck_ok'  ,
    'clk_sys_mon.status.pll_locked'  ,
    'acfg_cs'                        ,
    'acfg_sck'                       ,
    'acfg_mosi'                      ,
    'acfg_miso_o'                    ,
    'acfg_miso_i'                    ,
    'otp_xce'                         ,
    'otp_xread'                       ,
    'otp_xpgm'                       ,
    'dco_coarse(0)'                  ,
    'dco_coarse(1)'                   ,
    'dco_coarse(2)'                   ,
    'dco_coarse(3)'                   ,
    'dco_coarse(4)'                   ,
    'dco_fine(0)'                     ,
    'dco_fine(1)'                     ,
    'dco_fine(2)'                     ,
    'dco_fine(3)'                     ,
    'dco_fine(4)'                     ,
    'dco_fine(5)'                     ,
    'test_mon.afir_bist_results_0'    ,
    'test_mon.afir_bist_results_1'    ,
    'test_mon.afir_bist_results_2'    ,
    'vcfly_ov(0)'                     ,
    'vcfly_ov(1)'                     ,
    'vcfly_ov(2)'                     ,
    'vcfly_ov(3)'                     ,
    'vcfly_uv(0)'                     ,
    'vcfly_uv(1)'                     ,
    'vcfly_uv(2)'                     ,
    'vcfly_uv(3)'                     ,
    'mon_clk_ref'                    ,
    'mon_clk_dpll_fb'              ,
    'cq_3m'                           ,
    'ivs_fe_en(0)'                    ,
    'ivs_fsel0(0)'                    ,
    'ivs_fsel1(0)'                    ,
    'ivs_int_az(0)'                   ,
    'ivs_int_cscale(0)'               ,
    'ivs_in_gate(0)'                  ,
    'ivs_int_az_clamp(0)'             ,
    'rc_rds_int'                     ,
    'buf_fe_en'                      ,
    'buf_fsel(0)'                     ,
    'buf_fe_pchg'                    ,
    'buf_fe_az'                      ,
    'buf_fe_track'                   ,
    'adc_c_clamp'                    ,
    'bal_disable_dcu_a0_int'          ,
    'bal_disable_dcu_b0_int'          ,
    'bal_disable_dcu_a1_int'          ,
    'bal_disable_dcu_b1_int'          ,
    'clk_sys_mon.status.mode_div_changed_at_clk_sys',
    'clk_sys_mon.status.mode_m_div_changed_at_clk_sys',
    'clk_sys_mon.status.mode_ref_div_changed_at_clk_sys',
    'clk_sys_mon.status.mode_fb_div_changed_at_clk_sys',
    'clk_sys_mon.status.i2s_sck_ok_at_clk_sys',
    'clk_sys_mon.status.dco_clk_ok_at_clk_sys',
    'clk_sys_mon.status.pll_locked_at_clk_sys',
    'clk_sys_mon.status.phase_max_at_clk_sys',
    'clk_sys_mon.status.counters_syncronized_at_clk_sys'
  ];

  var self = this;
  this.sl = null;
  this.sd2 = null;
  this.dsl = null;
  this.db_div = null;
  this.enable = function() {
    this.db_div     = document.createElement('div');
    this.db_div.id  = 'db_wp';
    document.getElementsByTagName('body')[0].appendChild(this.db_div);
    this.sl = document.createElement('select');
    this.sl.id = 'sl_debug_mode';
    this.db_div.appendChild(this.sl);
    var i = 0;
    xpin_modes.forEach(m => {
      var o = document.createElement('option');
      o.value = i++;
      o.text  = m;
      this.sl.appendChild(o);
    });
    this.sl.onchange = function() {
      var val = document.getElementById('sl_debug_mode').selectedIndex;
      val = val + 0x10;
      console.log("Change value " + val);
      var core__test__xpin_mode__addr = [ 0x01e1, 0x0201] ;
      ws.send(new Uint8Array([1,0,(core__test__xpin_mode__addr[rev] & 0xff00)>>8 ,core__test__xpin_mode__addr[rev] & 0x00ff , val]));
    }
    this.sd2 = document.createElement('input');
    this.sd2.type='checkbox';
    this.sd2.value = "Enable I2S_SDO out";
    this.sd2.id = 'select_d2_out';
    this.db_div.appendChild(this.sd2);
    this.sd2.onchange = function() {
      var val = document.getElementById('select_d2_out').checked;
      console.log("value :" + val)
      if (val == true)
      {
        ws.send( new Uint8Array( [1,0,0x02,0x06,0xc0] ));
        ws.send( new Uint8Array( [1,0,0x00,0x25,0x0e] ));
      } else
      {
        ws.send( new Uint8Array( [1,0,0x02,0x06,0x00] ));
        ws.send( new Uint8Array( [1,0,0x00,0x25,0x0a] ));
      }
    }

    this.lnerr     = document.createTextNode("nerr");
    this.db_div.appendChild(this.lnerr);
    this.d_nerr_sl = document.createElement('select');
    this.d_nerr_sl.id = 'sl_digital_nerr_mode';
    this.db_div.appendChild(this.d_nerr_sl);
    var i = 0;
    xpin_digs.forEach(m => {
      var o = document.createElement('option');
      o.value = i++;
      o.text  = m;
      this.d_nerr_sl.appendChild(o);
    });
    this.d_nerr_sl.onchange = function() {
      var val = document.getElementById('sl_digital_nerr_mode').selectedIndex;
      console.log("Change value nerr " + val);
      var core__test__d1_mux_sel__addr = [ 2*256+91, 0x0203 ];
      ws.send(new Uint8Array([1,0,( core__test__d1_mux_sel__addr[rev]&0xff00 )>>8,
                                 ( core__test__d1_mux_sel__addr[rev]&0x00ff ), val]));
    }

    this.lnclip     = document.createTextNode("nclip");
    this.db_div.appendChild(this.lnclip);
    this.d_nclip_sl = document.createElement('select');
    this.d_nclip_sl.id = 'sl_digital_nclip_mode';
    this.db_div.appendChild(this.d_nclip_sl);
    var i = 0;
    xpin_digs.forEach(m => {
      var o = document.createElement('option');
      o.value = i++;
      o.text  = m;
      this.d_nclip_sl.appendChild(o);
    });
    this.d_nclip_sl.onchange = function() {
      var val = document.getElementById('sl_digital_nclip_mode').selectedIndex;
      console.log("Change value clip " + val);
      var core__test__d0_mux_sel__addr = [ 2*256+90 ,  0x0202 ];
      ws.send(new Uint8Array([1,0,( core__test__d0_mux_sel__addr[rev]&0xff00 )>>8,
                                  ( core__test__d0_mux_sel__addr[rev]&0x00ff ), val]));
    }
    if (rev == 1)  // and set test.i2s_sdo_debug_out = 1
                   // and set test.i2s_sdo_reclk_bypass = 1 addr 0x206   1100ffff
                   // and set i2s_tdm.tx_enable = 1         addr 0x25    ffff1110

    {
      this.li2s_sdo   = document.createTextNode("i2s_sdo");
      this.db_div.appendChild(this.li2s_sdo);
      this.d_i2s_sdo_sl = document.createElement('select');
      this.d_i2s_sdo_sl.id = 'sl_digital_i2s_sdo_mode';
      this.db_div.appendChild(this.d_i2s_sdo_sl);
      var i = 0;
      xpin_digs.forEach(m => {
        var o = document.createElement('option');
        o.value = i++;
        o.text  = m;
        this.d_i2s_sdo_sl.appendChild(o);
      });
      this.d_i2s_sdo_sl.onchange = function() {
        var val = document.getElementById('sl_digital_i2s_sdo_mode').selectedIndex;
        console.log("Change value clip " + val);
        var core__test__d2_mux_sel__addr = [ 2*256+90 , 0x0204 ];
        ws.send(new Uint8Array([1,0,( core__test__d2_mux_sel__addr[rev]&0xff00 )>>8,
                                    ( core__test__d2_mux_sel__addr[rev]&0x00ff ), val]));
      }
    }
  }


  this.disable = function() {
    document.body.removeChild(this.db_div);
  }
}


window.onload = function() { 
  i2sUpdate();
}  

var i2s_sck_pol    = 0;     //  wsInvert = 1; 
var i2s_ws_pol     = 0;     //  wsInvert = 1; 
var i2s_order      = 0;     //  Sample edian         0: MSB first
var i2s_rightfirst = 0;     //  LR word order. 0: Left first  
var i2s_format     = 1;     //  0:i2s, 1: left; 2:right 16, 3:right 18, 4:right:20, 5:right:24     
var i2s_framesize  = 0;     //  32/24/16
var i2s_framesize_lu = 32;    
var i2s_i = 0;
   
function i2sUpdate() {
  i2s_sck_pol    = (document.getElementById("i2s_sck_pol").checked==true)?1:0; 
  i2s_ws_pol     = (document.getElementById("i2s_ws_pol").checked==true)?1:0;
  i2s_order      = (document.getElementById("i2s_order").checked==true)?1:0;
  i2s_rightfirst = (document.getElementById("i2s_rightfirst").checked == true)?1:0;
  
  i2s_format     = document.getElementById("i2s_format").value;
  
  i2s_i          = document.getElementById("i2s_framesize").value;
  switch (i2s_i) { 
    case "0" : 
	  i2s_framesize_lu = 32 ; 
	  break;
	case "1" : 
	  i2s_framesize_lu = 24 ; 
	  break;
	case "2" : 
	  i2s_framesize_lu = 16 ; 
  	  if (i2s_format >= 3) { 
	    i2s_format = 0; 
	  }
	  break; 
  }	    
  
  drawCfgI2S();
}


function drawCfgI2S() { 
 // var i2s_sck_pol    = 0;     //  sckInvert = 0;
 // var i2s_ws_pol     = 0;     //  wsInvert = 1; 
 // var i2s_format     = 1 ;    //  0:i2s, 1: left; 2:right 16, 3:right 18, 4:right:20, 5:right:24     
 // var i2s_order      = 0 ;    //  Sample edian       0: MSB first
 // var i2s_rightfirst = 0 ;    //  LR word order. 0: Left first  
 
 var c = document.getElementById("cfgI2S");
 var ctx = c.getContext("2d");
 var lmt = 10;        // left margin text
 var lml = 50;        // left margin line
 var ls = 28;
 var lh = 16;        // line high   
 var lho = 10;       // line high offset 
 var l1 = lho + 1*ls;
 var l2 = lho + 2*ls;     
 var l3 = lho + 3*ls;
 var l4 = lho + 4*ls-ls/2; 
 
 var pxclk = 896/(i2s_framesize_lu*2);
 var pxclk2 = pxclk/2; 
 var i2s_format_str; 
 var i2s_first_bit;
 var i2s_nbits;
 switch (i2s_format) {  
   case "0" : i2s_format_str = "I2S"; 
              i2s_first_bit  = 1;
			  i2s_nbits      = i2s_framesize_lu; 
			  break;
   case "1" : i2s_format_str = "Left Justified";
              i2s_first_bit  = 0; 			   
			  i2s_nbits      = i2s_framesize_lu; 
			  break; 
   case "2" : i2s_format_str = "Right 16 bits";
              i2s_first_bit  = i2s_framesize_lu - 16; 
			  i2s_nbits      = 16;
			  break;
   case "3" : i2s_format_str = "Right 18 bits";
              i2s_first_bit  = i2s_framesize_lu - 18; 
			  i2s_nbits      = 18;
			  break;
   case "4" : i2s_format_str = "Right 20 bits";
              i2s_first_bit  = i2s_framesize_lu - 20; 
			  i2s_nbits      = 20;
			  break;
   case "5" : i2s_format_str = "Right 24 bits";
              i2s_first_bit  = i2s_framesize_lu - 24; 
			  i2s_nbits      = 24;
			  break;
 }
 
 ctx.clearRect(0, 0, cfgI2S.width, cfgI2S.height);
   
 ctx.font = "12px Arial";
 
 ctx.fillText("SCK",lmt, l1 );
 var h = l1-lh;
 var l = l1;  
 if (i2s_sck_pol == 1 )
 { h = l1; 
   l = l1-lh;
 }

 ctx.moveTo(lml, h);
 ctx.lineTo(lml + 3, h) 
 for (i = 0;i<=i2s_framesize_lu*2;i++) 
 {  
   ctx.lineTo(lml + 3 + i*pxclk,   h);
   ctx.lineTo(lml + 3 + i*pxclk+1, l);
   ctx.lineTo(lml + 3 + i*pxclk+pxclk2, l);
   ctx.lineTo(lml + 3 + i*pxclk+pxclk2+1, h);
 } 
 ctx.stroke(); 
 
 if (i2s_ws_pol == 1 )
 { h = l2; 
   l = l2-lh;
 }
 else 
 { h = l2-lh;
   l = l2;
 }

 ctx.beginPath();
 ctx.fillText("WS", lmt, l2);
 ctx.moveTo(lml, h);
 ctx.lineTo(lml + 3  ,h);
 ctx.lineTo(lml + 3 + 1 , l);
 ctx.lineTo(lml + 3 + i2s_framesize_lu*pxclk, l);
 ctx.lineTo(lml + 3 + i2s_framesize_lu*pxclk + 1, h);
 ctx.lineTo(lml + 3 + 2*i2s_framesize_lu*pxclk,     h); 
 ctx.lineTo(lml + 3 + 2*i2s_framesize_lu*pxclk + 1, l); 
 ctx.lineTo(lml + 3 + 2*i2s_framesize_lu*pxclk + 1 + 3, l);
 ctx.stroke(); 

 // Build data line 
 //---------------------------------------------------------------------------------------------- 
 ctx.beginPath();
 ctx.fillText("D0", lmt, l3);
 h = l3 - lh;
 l = l3;    
 
 if (i2s_format >= 2) 
 { ctx.moveTo(lml, h );
   ctx.lineTo(lml + 3, h);
   ctx.lineTo(lml + 3 + 1, l-lh/2 );
   ctx.moveTo(lml, l );
   ctx.lineTo(lml + 3, l);
   ctx.lineTo(lml + 3 + 1, l-lh/2 );
   ctx.lineTo(lml + 3 + (i2s_framesize_lu-i2s_nbits)*pxclk, l-lh/2);
 }
 else
 { ctx.moveTo(lml, h );
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk , h); 
 }
 
 for (i = 0; i < i2s_nbits/2; i++)
 {
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 1, l);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk , l);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk + 1, h);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 2*pxclk , h);
 } 
 if (i2s_format <= 1)
 { ctx.moveTo(lml, l );
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk , l); 
 }
 else 
 { ctx.moveTo(lml + 3 + (i2s_framesize_lu-i2s_nbits)*pxclk, l-lh/2); 
 }
 
 for (i = 0; i < i2s_nbits/2; i++)
 {
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 1, h);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk , h);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk + 1, l);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 2*pxclk , l);
 } 
 // 2nd Gap fill 
 if (i2s_format >= 2) { 
   ctx.moveTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk, h);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk + 1 , l-lh/2);
   ctx.moveTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk, l); 
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk + 1 , l-lh/2);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + i2s_framesize_lu*pxclk, l-lh/2); 
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + i2s_framesize_lu*pxclk + 1, h); 
   ctx.moveTo(lml + 3 + i2s_first_bit*pxclk + i2s_framesize_lu*pxclk, l-lh/2); 
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + i2s_framesize_lu*pxclk + 1, l); 
 } 
 else 
 { ctx.moveTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk, h);
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk + 1 , l);
   ctx.moveTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk, l); 
   ctx.lineTo(lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk + 1 , h);
 }

 // --- 2nd sample -----------------------------------------------------------------------------------
 ctx.moveTo(lml + 3 + i2s_first_bit*pxclk + i2s_framesize_lu*pxclk + 1, l); 
 for (i = 0; i < i2s_nbits/2; i++)
 {
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 1, l);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk , l);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk + 1, h);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 2*pxclk , h);
 } 
 if (i2s_format >= 2) { 
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + (i2s_nbits)*pxclk + 1, l - lh/2);    
 }  else {
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + (i2s_nbits)*pxclk + 1, l);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + (i2s_nbits)*pxclk + 1 + 3, l); 
 } 
 
 ctx.moveTo(lml + 3 + i2s_first_bit*pxclk + i2s_framesize_lu*pxclk + 1, h); 
 for (i = 0; i < i2s_nbits/2; i++)
 {
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 1, h);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk , h);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + pxclk + 1, l);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + 2*pxclk*i + 2*pxclk , l);
 } 
 if (i2s_format >= 2) { 
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + (i2s_nbits)*pxclk + 1, l - lh/2);    
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + (1+(i2s_nbits))*pxclk + 1, l - lh/2); 
 } else {
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + (i2s_nbits)*pxclk + 1, h);
   ctx.lineTo(lml + i2s_framesize_lu*pxclk + 3 + i2s_first_bit*pxclk + (i2s_nbits)*pxclk + 1 + 3 , h); 
 }
  
 ctx.stroke();        
 
 ctx.beginPath();
 var bit_first = "<MSB";
 var bit_last  = "LSB>"; 
 if (i2s_order == 1) { 
   bit_first = "<LSB"; 
   bit_last  = "MSB>";
 }
 
 var sample_first = "-- LEFT --";
 var sample_last  = "-- RIGHT --"; 
  if (i2s_rightfirst == 1) { 
   sample_first = "-- RIGHT --"; 
   sample_last  = "-- LEFT --"; 
 }    
 ctx.fillText(bit_first   , lml + 3 + 2 + i2s_first_bit*pxclk,l4);
 ctx.fillText(sample_first, lml + 3 + 2 + (i2s_first_bit + i2s_nbits/2)*pxclk - 30, l4); 
 ctx.fillText(bit_last    , lml + 3 + i2s_first_bit*pxclk + i2s_nbits*pxclk - 32 ,l4);   

 ctx.fillText(bit_first   , lml + 3 + i2s_framesize_lu*pxclk + 2 + i2s_first_bit*pxclk ,l4);
 ctx.fillText(sample_last , lml + 3 + i2s_framesize_lu*pxclk + 2 + (i2s_first_bit + i2s_nbits/2)*pxclk - 30, l4); 
 ctx.fillText(bit_last    , lml + 3 + i2s_framesize_lu*pxclk + i2s_first_bit*pxclk + i2s_nbits*pxclk - 32 ,l4);   
 

} 
 

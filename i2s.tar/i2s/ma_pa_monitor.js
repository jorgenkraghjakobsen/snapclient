// js object for UI monitoring and interact with powermodes

// Draw will redraw UI interface
// set will set power modes ch0 = [0:3] and ch1 = [0:3]
// To do : move all pm monitor related UX stuf here


var pa_monitor = null;
var ma120_rev = 1
function ma_pa_test() {
  if (!pa_monitor)
  { pa_monitor = new Pm_monitor();
    pa_monitor.enable();
    pa_monitor.pm = [0,0];
    pa_monitor.pm_manual = [1,1];
    pa_monitor.pmp = 0;
    pa_monitor.draw();
  }
}

function ma_pa_test2() {
  pa_monitor.disable();
  pa_monitor = null;
}

function isIntersect(coffx,coffy, pos, pm) {
  var x = pos.x - coffx;
  var y = pos.y - coffy;
  return ( (x>pm.x & x<(pm.x+pm.bx)) && (y>pm.y-pm.by) && (y<pm.y) );
};

function Pm_monitor() {
  const pms = [
    { x: 10, y: 18, bx:10,by:16, powermode:0, ch:0 , id : "ch0 pm 0"},
    { x: 20, y: 18, bx:10,by:16, powermode:1, ch:0 , id : "ch0 pm 1"},
    { x: 30, y: 18, bx:10,by:16, powermode:2, ch:0 , id : "ch0 pm 2"},
    { x: 40, y: 18, bx:10,by:16, powermode:3, ch:0 , id : "ch0 pm 3"},
    { x: 10, y: 36, bx:10,by:16, powermode:0, ch:1 , id : "ch1 pm 0"},
    { x: 20, y: 36, bx:10,by:16, powermode:1, ch:1 , id : "ch1 pm 1"},
    { x: 30, y: 36, bx:10,by:16, powermode:2, ch:1 , id : "ch1 pm 2"},
    { x: 40, y: 36, bx:10,by:16, powermode:3, ch:1 , id : "ch1 pm 3"}
  ];
  var self       = this;
  this.pms       = null;
  this.enabled   = 0;
  this.redraw    = 0;
  this.pm        = [ 0, 0];
  this.pm_old    = [-1, -1];
  this.pm_manual = [ 0, 0];
  this.canv      = null;
  this.pa_mon_div = null;
  this.disable   = function() {
    if (this.enabled == 1)
    {  this.redraw = 0;
       this.enabled = 0;
       document.body.removeChild(this.pa_mon_div);
       //document.body.removeChild(this.canv);
       //document.body.removeChild(this.c_vu);
       //document.body.removeChild(this.c_st);
    }
  };
  this.enable  = function() {
    if (this.enabled == 0)
    {  this.pa_mon_div     = document.createElement('div');
       this.pa_mon_div.id  = 'pam_mon_wp';
       document.getElementsByTagName('body')[0].appendChild(this.pa_mon_div);

       this.canv = document.createElement('canvas');
       this.canv.id     = 'pm_mon';
       this.canv.width  = 60;
       this.canv.height = 40;
       this.pa_mon_div.appendChild(this.canv);
       this.rect = this.canv.getBoundingClientRect();
       var coffx = this.rect.x;
       var coffy = this.rect.y;
       console.log('Draw pm_monitor init function');
       var ctx = this.canv.getContext('2d');

       this.c_vu = document.createElement('canvas');
       this.c_vu.id = 'meter';
       this.c_vu.width = 2*256;
       this.c_vu.height = 40;
       this.pa_mon_div.appendChild(this.c_vu);
       var ctx = this.canv.getContext('2d');
       this.c_st = document.createElement('canvas');
       this.c_st.id = 'st_mon';
       this.c_st.width = 400;
       this.c_st.height = 40;
       this.pa_mon_div.appendChild(this.c_st);
       this.redraw = 1;

       function pm_click(event) {
         const pos = { x: event.clientX,
                       y: event.clientY };
         pms.forEach(pme => {
           if (isIntersect(coffx,coffy, pos, pme)) {

             if (self.pm_manual[pme.ch] == 1)
             { if (self.pm[pme.ch] == pme.powermode)
               { self.pm_manual[pme.ch] = 0;
               }
               else
               { self.pm[pme.ch] = pme.powermode;
               }
             } else if (self.pm[pme.ch] == pme.powermode) {
                console.log('pressed active powermode: ch='+ pme.ch +', pm'+ pme.powermode );
                self.pm_manual[pme.ch] = (self.pm_manual[pme.ch] == 1 ) ? 0 : 1;
             }

             var val = (self.pm[1]<<5) + (self.pm[0]<<2)
                     + (self.pm_manual[1]<<1) +  self.pm_manual[0] ;


			 console.log("updatea pm :" + val);
             var core__reg__PM_man_force0_addr = [183, 167];
			 ws.send(new Uint8Array([1,0,0,core__reg__PM_man_force0_addr[ma120_rev],val]));    // rev0 -> 183
			                             		 											   // rev1 -> 167
             self.draw();
           }
         })
       }

       this.canv.addEventListener('click', pm_click.bind(null),false);
       this.enabled = 1;
    }
    else
    { console.log('Already defined');
    }
  };
  this.draw = function() {
    var i;
    if (this.pm_old[0] != this.pm[0])
    { var ctx = this.canv.getContext("2d");
      ctx.font = "18px Arial";
		  ctx.clearRect(0,0,60,20);
		  for ( i = 0 ;i <= 3 ;   i++) {
        ctx.strokeStyle = (this.pm[0] != i ) ? 'gray' : (this.pm_manual[0] == 1) ? 'red' :'green';
        ctx.strokeText(i,pms[i].x,pms[i].y);
		  }
    }
    if (this.pm_old[1] != this.pm[1])
    { var ctx = this.canv.getContext("2d");
      ctx.font = "18px Arial";
		  ctx.clearRect(0,20,60,40);
		  for ( i = 0 ;i <= 3 ;   i++) {
        ctx.strokeStyle = (this.pm[1] != i ) ? 'gray' : (this.pm_manual[1] == 1) ? 'red' :'green';
        ctx.strokeText(i,pms[4+i].x,pms[4+i].y);
		  }
    }
  };
};

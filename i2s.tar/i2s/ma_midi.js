navigator.requestMIDIAccess()
    .then(onMIDISuccess, onMIDIFailure);

function onMIDISuccess(midiAccess) {
    console.log(midiAccess);

    var inputs = midiAccess.inputs;
    var outputs = midiAccess.outputs;

    // Attach MIDI event "listeners" to each input
    for (var input of midiAccess.inputs.values()) {
        input.onmidimessage = getMIDIMessage;
    }
}

function onMIDIFailure() {
    console.log('Could not access your MIDI devices.');
}

function getMIDIMessage(message) {

    var command = message.data[0];
    console.log("Midi command:" + command);
    var channel = message.data[1];
    var value   = message.data[2];


    switch (command) {
        case 176: // Contoller
          switch (channel) {
            case 1: ch0_volume = 128 - value;
                    if (vol_linked) {
                      document.getElementById("ma_ctrl_ch0_volume").value = value;
                      document.getElementById("ma_ctrl_ch1_volume").value = value;
                      document.getElementById("ma_ch0_vol_txt").innerHTML = ((24-ch0_volume)).toString(10) + " dB";
                      document.getElementById("ma_ch1_vol_txt").innerHTML = ((24-ch0_volume)).toString(10) + " dB";
                      ws.send(new Uint8Array([1,0,0,3,ch0_volume]));
                      ws.send(new Uint8Array([1,0,0,4,ch0_volume]));
                    } else {
                      document.getElementById("ma_ctrl_ch0_volume").value = value;
                      document.getElementById("ma_ch0_vol_txt").innerHTML = ((24-ch0_volume)).toString(10) + " dB";
                      ws.send(new Uint8Array([1,0,0,3,ch0_volume]));
                    }
                    break;
            case 2: ch1_volume = 128 - value;
                    if (vol_linked) {
                      document.getElementById("ma_ctrl_ch0_volume").value = value;
                      document.getElementById("ma_ctrl_ch1_volume").value = value;
                      document.getElementById("ma_ch0_vol_txt").innerHTML = ((24-ch1_volume)).toString(10) + " dB";
                      document.getElementById("ma_ch1_vol_txt").innerHTML = ((24-ch1_volume)).toString(10) + " dB";
                      ws.send(new Uint8Array([1,0,0,3,ch1_volume]));
                      ws.send(new Uint8Array([1,0,0,4,ch1_volume]));
                    } else {
                      document.getElementById("ma_ctrl_ch1_volume").value = value;
                      document.getElementById("ma_ch1_vol_txt").innerHTML = ((24-ch1_volume)).toString(10) + " dB";
                      ws.send(new Uint8Array([1,0,0,4,ch1_volume]));
                    }
                    break;
             case 25 :

          }
          console.log("ch : " + channel + " = " + value );
          break;
        case 128: // note off
            noteOffCallback(note);
            break;
        // we could easily expand this switch statement to cover other types of commands such as controllers or sysex
      }
  }

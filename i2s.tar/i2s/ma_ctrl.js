var ch_mute_state = [ 0, 0 ];

var enable_state = 1;
var mute_state = 0;

var ch_volume = [ 0x60, 0x60 ];

var vol_linked = 1;

var offset_trim_ch0 = 0;
var offset_trim_ch1 = 0;

var maAudioStatusTimedOn = 0 ;
var TimedOnObj;

var tempGraph;
var tempSeries;

var pvddGraph;
var pvddSeries;

var aux0Graph;
var aux0Series;

var aux1Graph;
var aux1Series;

var pinGraph;
var pinSeries;


function initTempMonitor() {
  tempSeries = new TimelineDataSeries();
  tempGraph = new TimelineGraphView('tempGraph','tempCanvas');
  tempGraph.updateEndDate();
  pvddSeries = new TimelineDataSeries();
  pvddGraph = new TimelineGraphView('pvddGraph','pvddCanvas');
  pvddGraph.updateEndDate();

  aux0Series = new TimelineDataSeries();
  aux0Graph = new TimelineGraphView('aux0Graph','aux0Canvas');
  aux0Graph.updateEndDate();

  aux1Series = new TimelineDataSeries();
  aux1Graph = new TimelineGraphView('aux1Graph','aux1Canvas');
  aux1Graph.updateEndDate();

  pinSeries = new TimelineDataSeries();
  pinGraph = new TimelineGraphView('pinGraph','pinCanvas');
  pinGraph.updateEndDate();
}

// power mode control
//   Adds a click event-handler on the powermode monitor.
//   Click on already seleced power mode in manual pm to enable auto pm mode
//   Click on power mode 0-3 in auto powermode to bring you to manual pm given pm
//  XXX to do auto generate 2x4 power modes

function maSetup() {
  ws.send(new Uint8Array([1,0,53,0x08]));
}

function maStatus() {
  ws.send(new Uint8Array([1,3,1,26,2]));
}

function maAudioStatus() {
  ws.send(new Uint8Array([1,3,0,183,5]));
}
function maAudioIndexStatus() {
  ws.send(new Uint8Array([1,16]));
}
function maClearErrAcc() {
  ws.send(new Uint8Array([1,0,1,9,2]));
  ws.send(new Uint8Array([1,0,1,9,0]));
}

function maAudioStatusTimed() {
  if (maAudioStatusTimedOn == 0)
  { maAudioStatusTimedOn = 1;
    TimedOnObj = setInterval(maAudioIndexStatus,500);
    console.log("maAudioStatusOn on");
  }
  else
  { maAudioStatusTimedOn = 0;
    clearTimeout(TimedOnObj);
    console.log("maAudioStatusOn off  ");

  }
}


function pinstate(pin)
{ var state = 0;
  switch ( pin ) {
    case 26 :
      state = enable_state = (enable_state) ? 0 : 1 ;
      break;
    case 27 :
      state = mute_state = (mute_state) ? 0 : 1 ;
      break;
    default:
      console.log("Error pin pressed");
      return ;
  }
  ws.send(new Uint8Array([2,1,pin,state]));
}


function ma_ctrl_ch_mute_click(ch) {
  //var mute_state = ma_ctrl_getMuteState();
  ch_mute_state[ch] = (ch_mute_state[ch])?0:1;

  // haredware or soft reg
   //ws.send(new Uint8Array([2,1,1,ch0_mute_state]));
  console.log("Ch" + ch + " Mute state :" + ch_mute_state[ch] );
}


function ma_ctrl_ch_volume(ch) {
  var gui_ch_volume_value = [ document.getElementById("ma_ctrl_ch0_volume").value ,
                              document.getElementById("ma_ctrl_ch1_volume").value ];
  ch_volume[ch] = 128 - gui_ch_volume_value[ch];

  document.getElementById("ma_ch0_vol_txt").innerHTML = ((24-ch_volume[0])).toString(10) + " dB";
  document.getElementById("ma_ch1_vol_txt").innerHTML = ((24-ch_volume[1])).toString(10) + " dB";
  //ws.send(new Uint8Array([1,0,64,master_volume]));
  ws.send(new Uint8Array([1,0,0,3,ch_volume[0]]));
  ws.send(new Uint8Array([1,0,0,4,ch_volume[1]]));
}

function audioGenSourceChanged()
{
  console.log("Audio source change ");
}

function maLoadOffsetTrim(ch)
{ var trim;
  //ws.send(new Uitn8Array([3,5,ch]);
  if (ch == 0) {
    trim = 19;
    document.getElementById("maOffsetTrimCh0").value = trim;
    document.getElementById("maOffsetTrimCh0_txt").innerHTML = ((trim-16)).toString(10) ;

  } else {
    trim = 11;
    document.getElementById("maOffsetTrimCh1").value = trim;
    document.getElementById("maOffsetTrimCh1_txt").innerHTML = ((trim-16)).toString(10) ;
  }
  ws.send(new Uint8Array([3,4,ch,trim]))
}

function maOffsetTrim(ch)
{ var trim;
  if (ch == 0) {
    trim = document.getElementById("maOffsetTrimCh0").value;
    document.getElementById("maOffsetTrimCh0_txt").innerHTML = ((trim-16)).toString(10) ;

  } else
  { trim = document.getElementById("maOffsetTrimCh1").value;
    document.getElementById("maOffsetTrimCh1_txt").innerHTML = ((trim-16)).toString(10) ;
  }
  ws.send(new Uint8Array([3,4,ch,trim]));
  console.log("Offset trim " + ch + " : " + trim);
}

function sig_gen_ch0_offset() {
  offset_trim_ch0 = document.getElementById("sig_gen_ch0_offset").value;
  ws.send(new Uint8Array([3,4,0,offset_trim_ch0]));
  console.log("Offset trim ch0 : " + offset_trim_ch0);
}

function sig_gen_ch1_offset() {
  offset_trim_ch1 = document.getElementById("sig_gen_ch1_offset").value;
  ws.send(new Uint8Array([3,4,1,offset_trim_ch1]));
  console.log("Offset trim ch1 : " + offset_trim_ch1);
}
